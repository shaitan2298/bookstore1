package com.cg.bookstore.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer 
{
  @Id
  String email;
  String fullName;
  String password;
  String phoneNumber;
  String address;
  String city;
  String zipCode;
  String country;
  
  @OneToMany
  public List<Orders> orders;
  
  public Customer()
  {
	  
  }

public Customer(String email, String fullName, String password, String phoneNumber, String address, String city,
		String zipCode, String country) {
	super();
	this.email = email;
	this.fullName = fullName;
	this.password = password;
	this.phoneNumber = phoneNumber;
	this.address = address;
	this.city = city;
	this.zipCode = zipCode;
	this.country = country;
}



public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getFullName() {
	return fullName;
}

public void setFullName(String fullName) {
	this.fullName = fullName;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getPhoneNumber() {
	return phoneNumber;
}

public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public String getZipCode() {
	return zipCode;
}

public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
}

public String getCountry() {
	return country;
}

public void setCountry(String country) {
	this.country = country;
}

public List<Orders> getOrders() {
	return orders;
}

public void setOrders(List<Orders> orders) {
	this.orders = orders;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((address == null) ? 0 : address.hashCode());
	result = prime * result + ((city == null) ? 0 : city.hashCode());
	result = prime * result + ((country == null) ? 0 : country.hashCode());
	result = prime * result + ((email == null) ? 0 : email.hashCode());
	result = prime * result + ((fullName == null) ? 0 : fullName.hashCode());
	result = prime * result + ((password == null) ? 0 : password.hashCode());
	result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
	result = prime * result + ((zipCode == null) ? 0 : zipCode.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (address == null) {
		if (other.address != null)
			return false;
	} else if (!address.equals(other.address))
		return false;
	if (city == null) {
		if (other.city != null)
			return false;
	} else if (!city.equals(other.city))
		return false;
	if (country == null) {
		if (other.country != null)
			return false;
	} else if (!country.equals(other.country))
		return false;
	if (email == null) {
		if (other.email != null)
			return false;
	} else if (!email.equals(other.email))
		return false;
	if (fullName == null) {
		if (other.fullName != null)
			return false;
	} else if (!fullName.equals(other.fullName))
		return false;
	if (password == null) {
		if (other.password != null)
			return false;
	} else if (!password.equals(other.password))
		return false;
	if (phoneNumber == null) {
		if (other.phoneNumber != null)
			return false;
	} else if (!phoneNumber.equals(other.phoneNumber))
		return false;
	if (zipCode == null) {
		if (other.zipCode != null)
			return false;
	} else if (!zipCode.equals(other.zipCode))
		return false;
	return true;
}

@Override
public String toString() {
	return "Customer [email=" + email + ", fullName=" + fullName + ", password=" + password + ", phoneNumber="
			+ phoneNumber + ", address=" + address + ", city=" + city + ", zipCode=" + zipCode + ", country=" + country
			+ ", orders=" + orders + "]";
}


  
  
}
