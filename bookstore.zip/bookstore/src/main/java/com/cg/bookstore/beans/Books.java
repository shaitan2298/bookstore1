package com.cg.bookstore.beans;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Books 
{
  @Id
  String isbn;
  String author;
  String title;
  String description;
  String thumbNailImage;
  float price;
  Date publishDate;
  @OneToOne
  public Category category;
 
  
  public Books()
  {
	  
  }

public String getIsbn() {
	return isbn;
}

public void setIsbn(String isbn) {
	this.isbn = isbn;
}

public String getAuthor() {
	return author;
}

public void setAuthor(String author) {
	this.author = author;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public String getThumbNailImage() {
	return thumbNailImage;
}

public void setThumbNailImage(String thumbNailImage) {
	this.thumbNailImage = thumbNailImage;
}

public float getPrice() {
	return price;
}

public void setPrice(float price) {
	this.price = price;
}

public Date getPublishDate() {
	return publishDate;
}

public void setPublishDate(Date publishDate) {
	this.publishDate = publishDate;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((author == null) ? 0 : author.hashCode());
	result = prime * result + ((description == null) ? 0 : description.hashCode());
	result = prime * result + ((isbn == null) ? 0 : isbn.hashCode());
	result = prime * result + Float.floatToIntBits(price);
	result = prime * result + ((publishDate == null) ? 0 : publishDate.hashCode());
	result = prime * result + ((thumbNailImage == null) ? 0 : thumbNailImage.hashCode());
	result = prime * result + ((title == null) ? 0 : title.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Books other = (Books) obj;
	if (author == null) {
		if (other.author != null)
			return false;
	} else if (!author.equals(other.author))
		return false;
	if (description == null) {
		if (other.description != null)
			return false;
	} else if (!description.equals(other.description))
		return false;
	if (isbn == null) {
		if (other.isbn != null)
			return false;
	} else if (!isbn.equals(other.isbn))
		return false;
	if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
		return false;
	if (publishDate == null) {
		if (other.publishDate != null)
			return false;
	} else if (!publishDate.equals(other.publishDate))
		return false;
	if (thumbNailImage == null) {
		if (other.thumbNailImage != null)
			return false;
	} else if (!thumbNailImage.equals(other.thumbNailImage))
		return false;
	if (title == null) {
		if (other.title != null)
			return false;
	} else if (!title.equals(other.title))
		return false;
	return true;
}

@Override
public String toString() {
	return "Books [isbn=" + isbn + ", author=" + author + ", title=" + title + ", description=" + description
			+ ", thumbNailImage=" + thumbNailImage + ", price=" + price + ", publishDate=" + publishDate + "]";
}
  
  
}
