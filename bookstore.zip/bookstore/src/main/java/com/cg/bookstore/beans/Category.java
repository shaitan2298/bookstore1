package com.cg.bookstore.beans;

public class Category 
{
   String categoryName;
}
